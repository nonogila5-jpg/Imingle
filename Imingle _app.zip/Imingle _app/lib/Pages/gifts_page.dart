import 'package:flutter/material.dart';

class GiftsPage extends StatelessWidget {
  const GiftsPage({super.key});

  @override
  Widget build(BuildContext context) {
    final gifts = ["🌹 Rose", "🎁 Gift Box", "💎 Diamond", "🍫 Chocolate"];

    return Scaffold(
      appBar: AppBar(title: const Text("Gifts")),
      body: ListView.builder(
        itemCount: gifts.length,
        itemBuilder: (context, index) => ListTile(
          title: Text(gifts[index]),
          trailing: ElevatedButton(
            child: const Text("Send"),
            onPressed: () {
              ScaffoldMessenger.of(context).showSnackBar(
                SnackBar(content: Text("Sent ${gifts[index]}")),
              );
            },
          ),
        ),
      ),
    );
  }
}