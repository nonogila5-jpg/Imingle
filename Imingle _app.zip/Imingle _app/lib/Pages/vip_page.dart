import 'package:flutter/material.dart';

class VipPage extends StatelessWidget {
  const VipPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("VIP Room")),
      body: const Center(
        child: Text("Exclusive VIP Content 🎉"),
      ),
    );
  }
}