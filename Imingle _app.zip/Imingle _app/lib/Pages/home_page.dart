import 'package:flutter/material.dart';

class HomePage extends StatelessWidget {
  const HomePage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("IMingle Home")),
      body: ListView(
        children: const [
          ListTile(title: Text("Chat Room 1")),
          ListTile(title: Text("Chat Room 2")),
          ListTile(title: Text("VIP Lounge")),
        ],
      ),
    );
  }
}